# CẢNH SÁT VIỆT REALM - Discord Moderation Bot

## Overview
CẢNH SÁT VIỆT REALM is a Discord server management bot with automatic moderation features, built with Python using discord.py.

## Features

### Slash Commands (prefix: /vr)

#### Moderation Commands
| Command | Description | Parameters |
|---------|-------------|------------|
| `/vrban` | Ban user from server | `user`, `duration?`, `reason?` |
| `/vrunban` | UnBan user | `user`, `reason?` |
| `/vrmute` | Mute user (Discord timeout) | `user`, `duration?`, `reason?` |
| `/vrunmute` | UnMute user | `user`, `reason?` |
| `/vrwarn` | Warn user | `user`, `reason?` |
| `/vrunwarn` | Remove 1 warning | `user`, `reason?` |

#### Configuration Commands
| Command | Description | Parameters |
|---------|-------------|------------|
| `/vrsetlog` | Set log channel | `channel` |
| `/vrsetmutedrole` | Set muted role | `role` |
| `/vrbypass` | Add/Remove bypass | `type`, `id` |

#### Info Commands
| Command | Description |
|---------|-------------|
| `/vrhelp` | Show command list |
| `/vrstatus` | Check bot status |

### Authorization System
- File-based authorization: Only users in `data/authorized_users.json` can use moderation commands
- Add User ID to `authorized_users` array in the JSON file

### Logging System
- Ban/Mute/UnBan/UnMute: Send embed to log channel
- Warn: Reply directly in the chat channel

### Auto Moderation
- Auto Ban/Mute when blocked words detected
- 3-Level Warning System:
  - Warn 1: Warning only
  - Warn 2: Auto Mute 10 minutes
  - Warn 3: Auto Ban 1 day
- Anti-Spam (messages, emoji, mentions, channel hopping)
- Anti-Scam/Token Logger detection
- Auto delete blocked links

### Duration Format
| Format | Duration |
|--------|----------|
| `s` | seconds |
| `m` | minutes |
| `h` | hours |
| `d` | days |
| `w` | weeks |
| `mo` | months |
| (empty) | permanent (max 28 days for mute) |

## Project Structure

```
├── main.py                      # Entry point, bot initialization
├── src/
│   ├── __init__.py
│   ├── utils.py                 # Utilities: JSON storage, embed builder, duration parser
│   ├── moderation.py            # Slash commands moderation
│   ├── automod.py               # Auto moderation, warning system
│   ├── antispam.py              # Anti-spam detection
│   └── antilink.py              # Anti-link, scam detection
├── data/
│   ├── config.json              # Guild settings, bypass lists
│   ├── authorized_users.json    # List of authorized user IDs
│   ├── ban-mute.json            # Ban/mute records
│   ├── ban-mute-BlockWord.json  # Blocked words & scam domains
│   └── warn.json                # User warnings
```

## Setup

1. Add `DISCORD_BOT_TOKEN` to Secrets
2. Add User IDs to `data/authorized_users.json`:
```json
{
  "authorized_users": [123456789012345678],
  "description": "List of user IDs authorized to use moderation commands"
}
```
3. Run bot with `python main.py`

## Dependencies
- discord.py (v2.0+)
- aiofiles
- python-dotenv

## Recent Changes
- 2024-12-03:
  - Changed all action names to English (Ban, Mute, Warn, UnBan, UnMute, UnWarn)
  - Rewrote /vrhelp command with full command list
  - Mute now always applies Discord timeout (max 28 days if no duration)
  - Changed bot name to "CẢNH SÁT VIỆT REALM"
  - File-based authorization system (authorized_users.json)
  - Ban/Mute send to log channel, Warn replies directly
